package nopcommerce.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.Select;

import nopcommerce.datareader.DataReader;

public class Login {
	WebDriver driver;
	DataReader ee;

	// Constructor to accept WebDriver instance
	public Login(WebDriver driver) {
		this.driver = driver;
	}

	public void landingPage() {
		// to get the current url
		driver.getCurrentUrl();
	}

	public String title() {
		String title = driver.getTitle();
		System.out.println(title);
		return title;
	}

	// Page Object Model
	By reg = By.linkText("Register");
	By gender = By.id("gender-female");
	By fname = By.id("FirstName");
	By lname = By.id("LastName");
	By dd = By.xpath("//*[@id=\"main\"]/div/div/div/div[2]/form/div[1]/div[2]/div[4]/div/select[1]");
	By mm = By.xpath("//*[@id=\"main\"]/div/div/div/div[2]/form/div[1]/div[2]/div[4]/div/select[2]");
	By yy = By.xpath("//*[@id=\"main\"]/div/div/div/div[2]/form/div[1]/div[2]/div[4]/div/select[3]");
	By email = By.id("Email");
	By com = By.id("Company");
	By pass = By.id("Password");
	By con = By.linkText("Continue");
	By log = By.linkText("Log in");
	By mail = By.className("email");

	public WebDriver uesrReg() {
		driver.findElement(reg).click();
		driver.findElement(gender).click();

		WebElement name = driver.findElement(fname);
		name.sendKeys("sobha");

		WebElement lastName = driver.findElement(lname);
		lastName.sendKeys("soniya");

		Select DateOfBirth = new Select(driver.findElement(dd));
		DateOfBirth.selectByVisibleText("12");

		Select month = new Select(driver.findElement(mm));
		month.selectByVisibleText("December");

		Select years = new Select(driver.findElement(yy));
		years.selectByVisibleText("2000");

		driver.findElement(email).sendKeys("sobhasoniya@gmail.com");

		driver.findElement(com).sendKeys("ust");

		driver.findElement(pass).sendKeys("Sobha123" + Keys.TAB + "Sobha123" + Keys.ENTER);

		driver.findElement(con).click();
		return driver;
	}

	public  WebDriver login() {
		int totalRows=ee.getRowCount(0);
		for(int i=0;i<totalRows;i++) {
		driver.findElement(log).click();
		driver.findElement(mail).sendKeys(ee.getData(0, i, 0)+Keys.TAB+ee.getData(0, i, 1)+Keys.ENTER);
		
		}
		return driver;
		
	}
	}
