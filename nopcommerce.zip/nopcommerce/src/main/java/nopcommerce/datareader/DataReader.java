package nopcommerce.datareader;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataReader {
	FileInputStream fis;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	public void ExcelDatas() throws IOException{
		String path =System.getProperty("user.dir")+"\\Datas\\Datas.xlsx";
		fis = new FileInputStream(path);
		workbook =new XSSFWorkbook(fis);
	}
	public String getData(int sheet_No,int row,int cell) {
		return workbook.getSheetAt(sheet_No).getRow(row).getCell(cell).getStringCellValue();	
	}
	public int getRowCount(int sheet_No) {
		return workbook.getSheetAt(sheet_No).getLastRowNum();
	}

}
