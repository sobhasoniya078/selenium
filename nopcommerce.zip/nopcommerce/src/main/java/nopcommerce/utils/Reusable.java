package nopcommerce.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Reusable {
	public static void takeScreenshot(WebDriver driver) throws IOException {
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		  File dest = new File("screenshots/screenshot"+System.currentTimeMillis()+".png");
		  FileUtils.copyFile(screenshotFile, dest);
		}

}
