package nopcommerce.pages;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class Search {
	
	WebDriver driver;
	// Constructor to accept WebDriver instance
    public Search(WebDriver driver) {
        this.driver = driver;
    }
    //Page objects
    By find=By.id("small-searchterms");
    By add=By.xpath("//*[@id=\"main\"]/div/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div[1]/div/div[2]/div[3]/div[2]/button[1]");
  By cart=By.linkText("Shopping cart");
  By terms=By.id("termsofservice");
  By btn=By.id("checkout");
    
    public WebDriver searchProduct() {
    	driver.findElement(find).sendKeys("Cell phones"+Keys.ENTER);
    	
    	//assertEquals(text,"Cell phones");
    	
    	
		return driver;
    	
    }
    public String keyword() {
    	String text=driver.findElement(By.xpath("//*[@id=\"q\"]")).getText();
		return text;
    }
    public boolean getalert() {
    	Boolean alert=driver.findElement(By.xpath("//*[@id=\"bar-notification\"]/div")).isDisplayed();
    	return alert;
    }
    
    public WebDriver addToCart() {
    	driver.findElement(add).click();
    	//assertEquals();
    	
		return driver;
    	
    }
    public WebDriver purchase() {
    	driver.findElement(cart).click();
    	driver.findElement(terms).click();
    	driver.findElement(btn).click();
    	
    	
		return driver;
    	
    }

}
