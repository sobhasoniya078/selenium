package cucumberdemo.cucu;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchTest {
WebDriver driver;
	
	private static final String SEARCHLOC = "input[id^='gh']:nth-child(2)";
	private static final String SUBMITBTN = "input[id^='gh']:nth-child(1)";
	
	@Before
	public void setup() {
		driver = new ChromeDriver();
	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
	}

	@Given("the user in the eBay home page")
	public void the_user_in_the_e_bay_home_page() {
		driver.get("https://ebay.com");
	}
	
	@When("the search string is entered")
	public void the_search_string_is_entered() {
		driver.findElement(By.cssSelector(SEARCHLOC)).sendKeys("Samsung");		
	}
	
	@And("a category is selected")
	public void a_category_is_selected() {
		WebElement cat=driver.findElement(By.id("gh-cat"));
		Select dd=new Select(cat);
		dd.selectByVisibleText(" Cell Phones & Accessories");
		
	}
	
	@And("the search button is clicked")
	public void the_search_button_is_clicked() {
		driver.findElement(By.cssSelector(SUBMITBTN)).click();
	}
	
	@Then("the search results page for the category selected should be displayed")
	public void the_search_results_page_for_the_category_selected_should_be_displayed() {
		String exurl="https://www.ebay.com/sch/i.html?_from=R40&_trksid=p4432023.m570.l1313&_nkw=samsung&_sacat=550";
		assertTrue(exurl.contains("_nkw=samsung"));
		assertTrue(exurl.contains("_sacat=550"));
	}
		
	
	
	@Then("the search results page should be displayed")
	public void the_search_results_page_should_be_displayed() {
		String expectedURL = "https://www.ebay.com/sch/i.html?_from=R40&_trksid=p4432023.m570.l1313&_nkw=Samsung&_sacat=0";
		assertTrue(expectedURL.contains("_nkw=Samsung"));
		assertTrue(expectedURL.contains("_sacat=0"));	
    }
}

