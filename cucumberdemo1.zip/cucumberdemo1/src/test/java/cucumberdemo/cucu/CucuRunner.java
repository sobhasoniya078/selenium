package cucumberdemo.cucu;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"C:\\Users\\271501\\eclipse-workspace\\cucumberdemo1\\src\\test\\java\\cucumberdemo\\cucu"},
		glue = {"cucumberdemo.cucu"}
		)

public class CucuRunner extends AbstractTestNGCucumberTests{}

