package array;

import java.util.*;

public class Array {
	/*
	 * public static void main(String args[]) { //printing an array int[] arr=
	 * {22,33,44,55,99}; for (int i=0;i<arr.length;i++) {
	 * System.out.println(arr[i]); } // get a array from the user and print it
	 * Scanner sc =new Scanner(System.in);
	 * System.out.println("enter the limit of the array:"); int n= sc.nextInt();
	 * int[] array = new int[n];
	 * System.out.println("Enter the elements of the array: "); for(int i=0; i<n;
	 * i++) { //reading array elements from the user array[i]=sc.nextInt(); }
	 * System.out.println("Array elements are: "); // accessing array elements using
	 * the for loop for (int i=0; i<n; i++) { System.out.println(array[i]); }
	 * 
	 * 
	 * }
	 */
	
	public static void main(String args[])
	{
		//ArrayList
		/*
		 * ArrayList <Integer> al= new ArrayList <Integer>(); al.add(1); al.add(6);
		 * al.add(4); al.add(7); al.add(9);
		 * 
		 * for(Integer n:al) { System.out.println(n); }
		 */
		//Get an arrayList from user and print it
		
		
	
		
	}


	 
}
