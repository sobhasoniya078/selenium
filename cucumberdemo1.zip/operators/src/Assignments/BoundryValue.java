package Assignments;

import java.util.Arrays;
import java.util.Scanner;

public class BoundryValue {
	public static float getBoundaryAverage(int arr[])
	{
		Arrays.sort(arr);
		int avg=0;
		for(int i=0;i<arr.length;i++)
		{
			int min=arr[i];
			int max=arr[arr.length-1];
			
			avg=(max+min)/2;
			
		}
		return avg;
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array :  ");
		int num=sc.nextInt();
		
		int[] arr=new int[5];
		for(int i=0;i<num;i++)
		{
			arr[i]=sc.nextInt();
		}
		float result=getBoundaryAverage(arr);
		System.out.println(result);
		
		
	}
	
	

}
