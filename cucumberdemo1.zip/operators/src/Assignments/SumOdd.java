package Assignments;

import java.util.Scanner;

public class SumOdd {
	int sum=0;
	public int sumOfOdd(int n)
	{
		for(int i=1;i<n;i++) { //loop for traverse
			if(i%2!=0) 
			{
				 sum=sum+i; //add the  odd numbers
			}
		}
		return sum;
		
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number"); //get a value from  user
		int n=sc.nextInt();
		SumOdd obj=new SumOdd(); //create the object for class
		int res=obj.sumOfOdd( n);//invoke the method and pass the input as a parameter
		System.out.println(res);
		

	}

}
