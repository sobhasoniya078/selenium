package Assignments;

import java.util.Scanner;

public class DigitCompare {
	public static boolean checkDigit(int a,int b) {
		int digit1=a%10;
		int digit2=b%10;
		if(digit1==digit2) {
			return true;
		}
		return false;
	}
 
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a;
		a=sc.nextInt();
		int b;
		b=sc.nextInt();
       
		boolean result=DigitCompare.checkDigit(a,b);
		if(result==true) {
			System.out.println("TRUE");
		}
		else {
			System.out.println("FALSE");
		}
		
		return;
 
	}
 

}
