package Assignments;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class CommonElements {
	public static int sumCommonElements (int[] arr1,int[] arr2)
	{
		Set <Integer> set=new HashSet<Integer>(); // declare the set and store the unique values
		for(int num:arr1)
		{
			set.add(num);
		}
		int sum=-1;
		for(int num:arr2) //check the element is repeated
		{
			if(set.contains(num))
			{
				sum+=num+1;
			}
		}
		return sum;
		
	}
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array");
		int num=sc.nextInt();
		
		int arr1[]=new int[num];
		System.out.println("Enter the" +num+"Elements");
		for(int i=0;i<num;i++)
		{
		arr1[i]=sc.nextInt();
		}
		
		int arr2[]=new int[num];
		System.out.println("Enter the" +num+"Elements");
		for(int i=0;i<num;i++)
		{
		arr1[i]=sc.nextInt();
		}
		
		
		int result=sumCommonElements(arr1,arr2);
		System.out.println(result);
		
	}
	

}
