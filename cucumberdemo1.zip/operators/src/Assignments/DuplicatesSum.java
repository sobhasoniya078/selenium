package Assignments;

import java.util.Scanner;

public class DuplicatesSum {
	public static int getDistinctSum(int a,int b,int c) {
		int sum=0;
		if(a==b) {
			return c;
		}
		else if(a==c) {
			return b;
		}
		else if(b==c) {
			return a;
		}
		else {
			return a+b+c;
		}
	}
 
	public static void main(String[] args) {
		 Scanner scan = new Scanner(System.in);
	        int a;
	        a=scan.nextInt();
	        int b;
	        b=scan.nextInt();
	        int c;
	        c=scan.nextInt();
	        int result=DuplicatesSum.getDistinctSum(a, b, c);
	        System.out.println(result);
 
	}
 

}
