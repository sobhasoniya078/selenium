package Assignments;

import java.util.Scanner;

public class Digits {
	public static void main(String[] args)
	   {
		   Scanner sc=new Scanner(System.in);
			System.out.println("Enter the number: " );// get a imput
			int num=sc.nextInt();
			
		   int res=countSeven(num);//invoking the method
		   System.out.println(res);//printing the result
	   }
	   
	   public static int countSeven (int num)
	   {
		   int rem=0,count=0;
		   while(num>0)	  //get the digits separately and check whether it is seven or not
		   {
			   rem=num%10;
			   if(rem==7)
			   {
				   count++; //if the digit is seven then count 
			   }
			   num=num/10;
			   
		   }
		   return count;
	   }
		
		

}
