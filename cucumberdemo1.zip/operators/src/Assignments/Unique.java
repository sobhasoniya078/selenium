package Assignments;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Unique {
	public static int unique(int n)
	{
		List<Integer> arr= new ArrayList<>();
		while(n>0)
		{
			int d= n%10;
			
			if(!arr.contains(d))
			{
			  arr.add(d);
			}
			else
			{
				return -1;
			}
			n=n/10;
		}
		return 1;
		
		
	}
 

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();
		int a=unique(n);
		System.out.println(a);
		// TODO Auto-generated method stub

	}

}
