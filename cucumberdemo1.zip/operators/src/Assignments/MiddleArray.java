package Assignments;

import java.util.Scanner;

public class MiddleArray {
	
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the size of array"); //get the size and elements from the user
			int n=sc.nextInt();
			
			int[] arr=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			
			int res=getMiddleElement(arr);
			System.out.println(res);
			
		}
		
		public static int getMiddleElement(int arr[])
		{
			int res=0;
			if(arr.length%2==0) {
			res=arr[arr.length/2];}//half length is the index of the middle element
			else{
				res=arr[(arr.length/2)+1];
			}
			return res;
		}
	 
	}


