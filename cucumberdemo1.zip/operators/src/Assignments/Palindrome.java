package Assignments;

import java.util.Scanner;

public class Palindrome {
	
	public static void reverse(String str) {
		String rev="";
		for(int i=0; i<str.length(); i++) {
			char ch=str.charAt(i);
			rev=ch+rev;
			
			
		}
		System.out.println(rev);
		
		 if(rev.equals(str)) { System.out.println("It is a palindrome"); } else {
		 System.out.println("It is not a palindrome"); }
	}
	

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.next();
		reverse(str);
		
		
		 
	}

}
