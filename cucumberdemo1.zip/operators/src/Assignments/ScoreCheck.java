package Assignments;

import java.util.Scanner;

public class ScoreCheck {
	public static boolean getScores(int []arr) {
		int n=arr.length;
		for(int i=0;i<n;i++) {
			if(i!=n-1 && arr[i]==100 && arr[i+1]==100 )  {
				return true;
				
			}
		}
		return false;
	}
 
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n;
		n=sc.nextInt();
        int[] arr = new int[n];
        for(int j=0;j<n;j++){
            arr[j]=sc.nextInt();
        }
		boolean result=ScoreCheck.getScores(arr);
		if(result==true) {
			System.out.println("TRUE");
		}
		else {
			System.out.println("FALSE");
		}
		
		return;
 
	}
 

}
