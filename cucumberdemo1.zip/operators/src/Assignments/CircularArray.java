package Assignments;

import java.util.Scanner;

public class CircularArray {
	public static long replaceElements(long[] circularArray) {
		long[] replacedArray = new long[circularArray.length];
		long sum=0;
		for (int i=0; i<circularArray.length; i++) {
			if(i==0) {
				replacedArray[i] = Math.abs(circularArray[i+1] - circularArray[circularArray.length-1]);
			}
			else if(i==circularArray.length - 1) {
				replacedArray[i] = Math.abs(circularArray[0] - circularArray[circularArray.length-2]);
			}
			else {
				replacedArray[i] = Math.abs(circularArray[i-1] - circularArray[i+1]);
			}
		}
		for(int i=0;i<replacedArray.length;i++) {
			sum = sum + (replacedArray[i]^i);
		}
		long result = sum % (long) (Math.pow(10,9)+7);
		return result;
	}
 
	public static void main(String[] args) {
		System.out.println("Enter the number of elements: ");
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		long[] circularArray = new long[n];
		System.out.println("Enter the elements: ");
		for(int i=0; i<circularArray.length;i++) {
			circularArray[i] = input.nextInt();
		}
		long replacedArray = replaceElements(circularArray);
		System.out.println(replacedArray);
	}
 

}
