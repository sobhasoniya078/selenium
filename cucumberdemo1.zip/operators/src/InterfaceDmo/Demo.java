package InterfaceDmo;
//Interface declaration: by first user  
interface Drawable{  
void draw();  
}  
//Implementation: by second user  
class Rectangle implements Drawable{  
public void draw(){System.out.println("drawing rectangle");}  
 
}
 
 
public class Demo {
	public static void main(String args[]){   
		Drawable obj=new  Rectangle();
		obj.draw();
		
		}} 



