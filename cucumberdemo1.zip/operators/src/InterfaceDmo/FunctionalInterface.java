package InterfaceDmo;

//interface
interface sayable
{  
    void say(String msg);   //one abstract method "functional interface must contain one abstract method and n number of default methods
     
    default void doIt()
    {  
        System.out.println("Do it now");  
    }  
    
   
} 

public class FunctionalInterface implements  sayable{
	public static void main(String[] args) {  
	       
	        
	    	sayable obj =   new FunctionalInterface();
	        obj.say("Hello there");  
	        
	        obj.doIt();
	    }

	



@Override
public void say(String msg) {
	System.out.println(msg);
	
}}
