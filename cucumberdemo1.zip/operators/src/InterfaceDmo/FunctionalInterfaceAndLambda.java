package InterfaceDmo;

interface Drawableone{  
    public void draw();  
    
    default void run()
    {
    	System.out.println("Hello");
    }
     
}  

public class FunctionalInterfaceAndLambda {
	 public static void main(String[] args) 
	    {  
	        int width=10; 
	        
	        Drawableone obj = ()-> {
	        	
	        	System.out.println("Drawing "+width);   
	        	
	        	
	        };
	        obj.run();
	        obj.draw();
	        
	        
	        
	    }

}
