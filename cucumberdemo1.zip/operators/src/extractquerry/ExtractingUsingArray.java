package extractquerry;

import java.util.Scanner;

public class ExtractingUsingArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the querry : ");
		String input=sc.next();
		extract(input);
	}

	public static void extract(String input) {
		StringBuilder str= new StringBuilder(input);
		int from=str.indexOf("select");
		int to=str.indexOf("from");
		String clm=str.substring(from,to);
		
		System.out.println(clm);
		
		}
	}

