package Revice;

import java.util.Scanner;

public class index {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str = sc.nextLine();
		System.out.println("enter the index");
		int num = sc.nextInt();
		
		
		int len=str.length();
		
		 if(num<0||num>len)
		 {
			 
			 System.out.println("error.enter the valid index");
		 } else
			{
		 System.out.println(str.charAt(num));}
		 
		 
		
        sc.close();
	}
 

	
}

