package Revice;

public class lexiographic {
	public static void main(String[] args) {
        String str1 = "This is Exercise 3";
        String str2 = "This is Exercise 5";
 
        // Create StringBuilders for the strings
       StringBuilder sb1 = new StringBuilder(str1);
       StringBuilder sb2 = new StringBuilder(str2);
 
        // Compare the strings lexicographically
      int comparisonResult = sb1.toString().compareTo(sb2.toString());
    
         System.out.println(comparisonResult);
        
        if (comparisonResult < 0) {
            System.out.println("\"" + str1 + "\" is less than \"" + str2 + "\"");
        } else if (comparisonResult > 0) {
            System.out.println("\"" + str1 + "\" is greater than \"" + str2 + "\"");
        } else {
            System.out.println("\"" + str1 + "\" is equal to \"" + str2 + "\"");
        }
    }

}
