package Revice;

public class RepeatString {

	public static void main(String[] args) {
		int n=3;
		// TODO Auto-generated method stub
		String str="Cognizant";
		String sub=str.substring(str.length()-n);
		for(int i=0;i<n;i++) {
			str+=sub;
			
		}
		System.out.println(str);

	}

}
