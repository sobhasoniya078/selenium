package Revice;

public class lexi {
	public static void main(String[] args) {
		String str1 = "This is exercise 1";
		String str2 = "This is Exercise 1";
		if(str1.equalsIgnoreCase(str2)) System.out.println("This is exercise 1 is equal to This is Exercise 1");
		else System.out.println("not equals");
	}
 
}