package Revice;

public class StringImmutableExample {

	public static void main(String[] args)
	{
		String str="";
		
		 String names[] = {"Hello","mohan","jayabalan"};
		 StringImmutableExample obj = new StringImmutableExample();
		 obj.joinWords(names, str);
	}
	private void joinWords(String[] names,String str)
	{
		
		for(int i=0;i<names.length;i++){
			
			str=str+" "+ names[i];
		}		
		System.out.println(str);
	}
	private void joinWords(String[] names)
	{
		StringBuilder sb = new StringBuilder();
		for(String str : names)
		{
			sb.append(str);
		}
		String stringss = sb.toString();
	    System.out.println(stringss);
		
	}

}
