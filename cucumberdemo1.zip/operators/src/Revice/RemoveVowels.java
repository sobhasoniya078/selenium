package Revice;

public class RemoveVowels {

	public static void main(String[] args) {
		String s="capacity";
		StringBuilder sc=new StringBuilder();
		
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if((i+1)%2!=0)
			{
				sc.append(c);
			}
			else
			{
				if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U') 
				{
					continue;
				}
				else {
					sc.append(c);
				}
			}
		}
		System.out.println(sc);

	}

}
