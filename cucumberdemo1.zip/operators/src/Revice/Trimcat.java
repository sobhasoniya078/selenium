package Revice;

import java.util.Scanner;

public class Trimcat {

	public static void main(String[] args) {
		
   Scanner sc=new Scanner(System.in);
   System.out.println("enter a string : ");
   String str=sc.next();
   String trim="";
   trimCat( str,trim);
	}
	public static void trimCat(String str,String trim) {
		for (int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			trim+=ch;
			i++;
		}
		System.out.println(trim);
		
	}
	

}
