package Revice;

public class StringEncryption {
    public static void main(String[] args) {
    	String s="zzzzz";
    	 StringBuilder encryptedString = new StringBuilder();
         for (int i = 0; i < s.length(); i++) {
             char c = s.charAt(i);
             if (i % 2 !=0) { // Even positions remain unchanged
                 encryptedString.append(c);
             } else { // Odd positions
                 if (c == 'z') {
                     encryptedString.append('a');
                 } else {
                     encryptedString.append((char) (c + 1)); // Replace with the next character in alphabet
                 }
             }
         }
         System.out.println(encryptedString.toString());
     }
 }

