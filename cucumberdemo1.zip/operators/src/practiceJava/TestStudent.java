package practiceJava;

import java.util.ArrayList;
import java.util.List;

public class TestStudent {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List <Student> list=new ArrayList<>();

	}

}
