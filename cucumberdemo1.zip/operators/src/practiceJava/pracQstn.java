package practiceJava;

public class pracQstn {

//multiplication of to float numbers	
	static void floatMulti(float var1, float var2) {

		float mul = var1 * var2;
		System.out.println("product of " + var1 + "and " + var2 + " = " + mul);
	}

//swapping two numbers with third variable
	static void swapWithTemp(int a, int b) {

		int temp = 0;
		temp = a;
		a = b;
		b = temp;
		System.out.println("after10 swapping......");
		System.out.println("a = " + a);
		System.out.println("b = " + b);

	}

//swapping two number without third variable
	static void swapWithOutTemp(int x, int y) {
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("x = " + x);
		System.out.println("y = " + y);

	}

//check the number is greater,and print the difference
	public void DiffTwoNum(int p, int r) {
		if (p > r) {
			System.out.print("P is greater than q,and the difference is " + (p - r));
		}
	}

//check if the numbers are positive or negetive, either postive or negetive made the product otherwise add
	public void PosOrNeg(int a, int b) {
		if ((a < 0 && b < 0) || (a > 0 && b > 0)) {
			System.out.println("product of those numbers are " + (a * b));

		} else {
			System.out.print("sum = " + (a + b));
		}
	}
	
	public static void Prod(int num) {
		int prod=1;
		while (num > 0)
		{
            int b = num % 10;
			prod = prod * b;
			num = num / 10;
			
		}
		System.out.println(prod);
	}
	
	public static void sum(int num) {
		int sum=0;
		while (num>0)
		{
			System.out.println(num);
			int c = num % 10;
			sum = sum + c;
			num = num / 10;
		}
		System.out.println(sum);
	}
	
		
	

//check the number of  digit ,if it is 1 ,then print the num, if it is 2 then 
	public void DigitsPlay(int num) {
		int count = 0;
		

		while (num > 0) {
			int a = num % 10;

			num = num / 10;

			count++;
		}
		System.out.println(count);
      
		if (count == 1)
		{
			System.out.println(num);
		}
		else if (count == 2)
		{
		    sum(num);
		}
		else
		{
			Prod(num);	
		}
			

	}

}
