package practiceJava;

import java.util.*;

public class practiceJava {

	
	public static void main(String[] args) {
		pracQstn obj1=new pracQstn();
//get a number from user and print it
		/*
		 * Scanner scanner= new Scanner(System.in);
		 * System.out.print("Enter a number: ");
		 *  int num=scanner.nextInt();
		 * System.out.println("number="+num);
		 * 
		 * scanner .close();
		 */
//multiplication of to float numbers
		/*
		 * Scanner sc= new Scanner(System.in);
		 * System.out.println("Enter  float number:"); float var1=sc.nextFloat();
		 * System.out.println("Enter a another floating value:"); float
		 * var2=sc.nextFloat();
		 * 
		 *  obj1.floatMulti(var1,var2);
		 */
//swapping two numbers with third variable 
		
			/*
			 * Scanner scan=new Scanner(System.in);
			 * System.out.print("Enter a value for a :"); int a=scan.nextInt();
			 * System.out.print("Enter the value for b: "); int b=scan.nextInt();
			 * System.out.println("before swapping......"); System.out.println("a = "+a);
			 * System.out.println("b = "+b); obj1.swapWithTemp(
			 * a, b);
			 */
		  
		  
		
//swapping two number without third variable
			
			/*
			 * Scanner swap=new Scanner(System.in); System.out.print("Enter two numbers:");
			 * int x=swap.nextInt();
			 * 
			 * int y=swap.nextInt(); 
			 * obj1.swapWithOutTemp(x,y);
			 */
			 
//check the two numbers are greater or not,if greater then print the difference
		
		
			/*
			 * Scanner diff=new Scanner(System.in);
			 * System.out.println("Enter two numbers :"); int p=diff.nextInt(); int
			 * r=diff.nextInt(); obj1.DiffTwoNum(p, r);
			 */
		
//check if the numbers are positive or negetive, either postive or negetive made the product otherwise add
			/*
			 * Scanner PN =new Scanner(System.in); System.out.println("Enter two numbers:");
			 * int a=PN.nextInt(); int b=PN.nextInt(); obj1.PosOrNeg(a, b);
			 */
		
//check the number of  digit ,if it is 1 ,then print the num, if it is 2 then 
		Scanner Dig=new Scanner(System.in);
		System.out.print("Enter the number:");
		int num=Dig.nextInt();
		int sum=0;
		int prod=1;
		obj1.DigitsPlay(num);
		
				}


}
