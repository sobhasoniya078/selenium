package practiceJava;

import java.util.Scanner;

public class Solution {
    public static int auction(int[] bids) {
        int[] copy = new int[bids.length];
        int pos = 0;

        // Copying non-duplicate elements
        for (int i = 0; i < bids.length; i++) {
            int count = 0;
            for (int j = 0; j < bids.length; j++) {
                if (bids[i] == bids[j]) {
                    count++;
                }
            }
            if (count == 1) {
                copy[pos++] = bids[i];
            }
        }

        if (pos > 0) {
            int min = copy[0];
            for (int i = 1; i < pos; i++) {
                if (copy[i] < min) {
                    min = copy[i];
                } else {
                    return -1;
                }
            }
            for (int i = 0; i < bids.length; i++) {
                if (bids[i] == min) {
                    pos = i + 1;
                }
            }
            return pos;
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int N;
        N = scan.nextInt();
        int[] bids = new int[N];

        for (int j = 0; j < N; j++) {
            bids[j] = scan.nextInt();
        }
        int result;
        result = auction(bids);
        System.out.print(result);
        scan.close();
    }
}

