package Assignments_Recap;

public class NoArgConstructor {
	//constructor with no arguments
	public NoArgConstructor() {
		System.out.println("Default constructor");
	}

	public static void main(String[] args) {
		
		//create a obj
		NoArgConstructor obj=new NoArgConstructor();

	}

}
