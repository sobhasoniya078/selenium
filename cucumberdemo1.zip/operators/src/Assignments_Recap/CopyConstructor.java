package Assignments_Recap;

import java.util.Scanner;

public class CopyConstructor {
	 


	//pass the values
	public CopyConstructor(String name,int age) {
		System.out.println("Hello "+name+" ("+age+")");
	}

	/*
	 * //pass object as the argument public CopyConstructor(CopyConstructor obj) {
	 * System.out.println("Hello"+obj.name+"("+obj.age+")");
	 */
	
	

	public static void main(String[] args) {
		//get values from user
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name:  ");
		String name=sc.next();
		System.out.println("Enter your age:  ");
		int age=sc.nextInt();
		int id=1;
		
		CopyConstructor obj1=new CopyConstructor(name,age);
	
		
		
	}

}
