package Assignments_Recap;

import java.util.Scanner;

public class ConstructorOverloading {
	//No arg constructor
	public ConstructorOverloading() {
		System.out.println("hii");
	}
	//parameterized constructor
	public ConstructorOverloading(int a,int b) {
		System.out.println(a+b);
		System.out.println(a*b);
		
	}
	public ConstructorOverloading(int a, int b, int c) {
		System.out.println(a+b+c);
		System.out.println(a*b*c);
		
	}
	

	public static void main(String[] args) {
		
		
		ConstructorOverloading cs=new ConstructorOverloading(2,3,4);
		ConstructorOverloading cs2=new ConstructorOverloading(2,3);
		

	}

}
