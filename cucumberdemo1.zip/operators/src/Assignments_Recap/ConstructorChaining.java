package Assignments_Recap;

public class ConstructorChaining {
	ConstructorChaining(){
		this(5);
		System.out.println();
	}
	ConstructorChaining(int x){
		this(5,15);
	}
	ConstructorChaining(int x,int y){
		System.out.println(x*y);
	}
	

	public static void main(String[] args) {
		
		ConstructorChaining c=new ConstructorChaining();

	}

}
