package operators;

public class sample {
	public static void add(int a,int b) {
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		int a=10;
		int b=3;
		// TODO Auto-generated method stub
		 add(a,b);

	}

}
