package logicqustns;

import java.util.*;

public class LogicQuestns {
	public void sumCheck(int num) 
	{
		int sum=0; // declare sum
		while(num>0) 
		{
			
			int n=num%10;// get the remainder to find the last digit seperately
			if(n%2==0) // check the last digit is even or not
			{
				sum=sum+n; // if the n is odd then  sum 
			}
			num=num/10; // eliminate the lat digit

		}
		if (sum%2==0) {
			System.out.println("sum of odd digit is even");
		} // check the sum of  digits is odd or even
		else {
			System.out.println("sum of odd digit id odd");
		}

	}
	
	public void sumOfSquaresOfEvenDigits(int num) 
	{
		int sum=0; // declare sum
		while(num>0) 
		{
			
			int n=num%10;// get the remainder to find the last digit seperately
			if(n%2==0) // check the last digit is even or not
			{
				sum=sum+(n*n); // if the n is even then find the square
			}
			num=num/10; // eliminate the last digit

		}
		System.out.println(sum);
		
		
	}
//revere the number
	public void reverseNum(int num) {
		int rev=0;
		while(num>0) {
			int rem=num%10;
			 rev=(rev * 10) + rem; 
			 num=num/10;
			
		}
		System.out.println(rev);
	}
	
//get two arraylist as input and merge the arraylist and sort the arraylist and seperate some elements into third arraylist and display

	public void sortMergeAndSplit(ArrayList <Integer> list1,ArrayList <Integer> list2)
	{
		for (int l:list2)
		{
			list1.add(l); //merge the array
			
		}
		System.out.println("merged arr is: "); //print the merged array
		for(int m:list1) 
		{
			System.out.print(m+",");
		}
		
		/*
		 * for(int i=0;i<list1.size();i++) { for(int j=i+1;j<list1.size();j++) { if(i>j)
		 * { int temp = list1.get(j); list1.set(j, list1.get(j + 1)); list1.set(j + 1,
		 * temp);
		 * 
		 * }
		 * 
		 * 
		 * }
		 * 
		 * }
		 */
		Collections.sort(list1);//sort the list using sort function
		System.out.println("Sorted arr is: ");
		for(int n:list1) 
		{
			System.out.print(n+",");
		}
		
		
	}
// get the sum of power of the array elements
	public void getSumOfPower (int[] arr)
	{
		int sum=0;
		for(int ar:arr)
		{
			sum=sum+(ar*ar);
			
		}
		System.out.println("sum = "+sum);
	}
// difference between largest and smallest number of an array
	
	public void getBigDiff(int[] arr) 
	{
		int l=arr.length;
		for(int i=0;i<l;i++) // for loop for sorting an array
		{
			for(int j=i+1;j<l;j++) 
			{
				if(arr[i]>arr[j])
				{
				 int temp =arr[i];
				 arr[i]=arr[j];
				 arr[j]=temp;
				}
			}
		}
		System.out.println("sorted arr is: "); //print the sorted array
		for(int m:arr) 
		{
			System.out.println(m+",");
		}
		
		System.out.println("Differece between largest and smallest element is "+(arr[l-1]-arr[0]));

		
	}
}
