package logicqustns;

import java.util.*;

public class logicalquestins 
{
public static void main (String[] args) 
{
	// object of the class which held the methods
	LogicQuestns lq=new LogicQuestns();
// find the sum of odd digits
	Scanner sc= new Scanner(System.in);
	//System.out.println("enter  a number:");
	//int num=sc.nextInt();
	//lq.sumCheck(num);
// find the sum of square of even numbers
	//lq.sumOfSquaresOfEvenDigits(num);
//reversing a number
	//lq.reverseNum(num);
//get two arraylist as input and merge the arraylist and sort the arraylist and seperate some elements into third arraylist and display
	
	/*
	 * ArrayList <Integer> list1=new ArrayList <Integer>(); ArrayList <Integer>
	 * list2=new ArrayList <Integer>();
	 * System.out.println("Enter the elementsfor list1:"); for (int i=0;i<5;i++) {
	 * list1.add(sc.nextInt()); }
	 * System.out.println("Enter the elements for list2:"); for (int i=0;i<5;i++) {
	 * list2.add(sc.nextInt()); } lq.sortMergeAndSplit( list1,list2);
	 */
//getSumOfPower 
	/*System.out.println("enter the limit of the array:"); 
	int n= sc.nextInt();
	  int[] array = new int[n];
	  System.out.println("Enter the elements of the array: "); 
	  for(int i=0; i<n; i++) 
	  { //reading array elements from the user
		  array[i]=sc.nextInt();
		  }
	  System.out.println("Array elements are: "); // accessing array elements using loop
	  for (int j=0; j<n; j++)
	  { 
		  System.out.print(array[j]+",");
	  }
	  lq.getSumOfPower(array);*/
	
//getBigDiff
	System.out.println("enter the limit of the array:"); 
	int n= sc.nextInt();
	  int[] arr = new int[n];
	  System.out.println("Enter the elements of the array: "); 
	  for(int i=0; i<n; i++) 
	  { //reading array elements from the user
		  arr[i]=sc.nextInt();
		  }
	 
	lq.getBigDiff(arr);
	  
	  }

	
}


