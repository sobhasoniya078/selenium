package testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Reusable;
import pom.HomePage;
import pom.LoginPage;
import utils.ExcelReader;
import utils.ExtentReport;

@Listeners(ExtentReport.class)
public class VerifyLogin extends Reusable {
	WebDriver driver;
	LoginPage lp;
	HomePage hp;
	
	
	@BeforeTest
	public void setup() {
		driver=Reusable.invokeBrowser();
		driver.get(pro.getProperty("url"));
		lp=new LoginPage(driver);
		hp= new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@AfterTest
	 public void afterTest() {
		 driver.quit();
	 }
	@Test(dataProvider = "valid",priority=3) 
	  public void verifyvalidLogin(String n, String s) throws InterruptedException {
		  System.out.println(n+s);
		 
		  lp.enterUsername(n);
		  lp.enterPassword(s);
		  waits();
		  lp.clickLogin();
		  WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(10));
		  wait.until(ExpectedConditions.visibilityOf(hp.logout));
		  Boolean lo= hp.validateLogout();
		  waits();
		  assertEquals(lo,true);

	  }
		
		  @Test(dataProvider = "invalid",priority=2) public void
		  verifyInvalidLogin(String n, String s) throws InterruptedException {
		  System.out.println(n+s);
		 // hp.enterIntoLoginpage(); 
		  lp.enterUsername(n);
		  lp.enterPassword(s);
		  waits();
		  lp.clickLogin(); 
		  Thread.sleep(2000);
		  
		  String exp="Wrong password.";
		  String res=lp.invalidValidation();
		 // lp.closePage();
		  
		  
		  
		  }
		 
		
		  @Test(priority=1) public void verifyNullLogin() throws
		  InterruptedException {
		  
		  hp.enterIntoLoginpage();
		  
		  waits();
		  lp.clickLogin();
		  
		  Thread.sleep(2000);
		 String exp="Please fill out Username and Password.";
		  String msg=lp.nullValidation(); 
		  System.out.println(msg);
		  waits();
		  assertEquals(exp,msg);
		  
		  
		  
		  }
		 
	
	
	@DataProvider public String[][] valid() throws IOException { 
		  String path=System.getProperty("user.dir")+"\\src\\test\\resources\\datasource\\data.xlsx"; 
		  return ExcelReader.locate(path,"validdata");
	  
	  }
	@DataProvider public String[][] invalid() throws IOException { 
		  String path=System.getProperty("user.dir")+"\\src\\test\\resources\\datasource\\data.xlsx"; 
		  return ExcelReader.locate(path,"invaliddata");
	  
	  }
	

}
