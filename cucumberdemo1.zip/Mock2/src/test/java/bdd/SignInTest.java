package bdd;

import java.time.Duration;

import org.openqa.selenium.WebDriver;

import base.Reusable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import pom.HomePage;
import pom.LoginPage;
import pom.SignInPage;

public class SignInTest extends Reusable{
	WebDriver driver;
	LoginPage lp;
	HomePage hp;
	SignInPage sp;
	
	
	@Before
	public void setup() {
		driver=Reusable.invokeBrowser();
		driver.get(pro.getProperty("url"));
		lp=new LoginPage(driver);
		hp= new HomePage(driver);
		sp= new SignInPage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@After
	 public void afterTest() {
		 driver.quit();
	 }
	@Given("the user in the signup page")
	public void the_user_in_the_signup_page() {
		hp.enterIntoSignupPage();
	   }
	@Given("enter the  username")
	public void enter_the_username() {
	    }
	@Given("enter the  password")
	public void enter_the_password() {
	   }
	@When("user clicks the signup button")
	public void user_clicks_the_signup_button() {
	   }
	@When("It should display the alert")
	public void it_should_display_the_alert() {
	   }
	
	@When("It should displays the alert message")
	public void it_should_displays_the_alert_message() {
	    }
	@When("It should be in tha home page")
	public void it_should_be_in_tha_home_page() {
	    }

}
