package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignInPage {
	WebDriver driver;
	@FindBy(id="sign-username")
	WebElement uname;
	
	@FindBy(id="sign-password")
	WebElement pas;
	
			@FindBy(className="btn-primary")
	WebElement signIn; 
	
	public SignInPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	public void enterUserName(String n) {
		uname.sendKeys(n);
	}
	public void enterPass(String p) {
		pas.sendKeys(p);
	}
	 
	public void clicksignIn() {
		signIn.click();
	}

}
