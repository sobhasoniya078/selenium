package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;
	
	@FindBy(id="login2")
	WebElement log;
	
	@FindBy(id="loginusername")
	
	WebElement name;
	
	@FindBy(id="loginpassword")
	WebElement pass;
	
	@FindBy(xpath="//button[@onclick='logIn()']")
	WebElement btn;
	
	@FindBy(className="btn-secondary")
	WebElement close;
	/************************constructor***************************/
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public HomePage clickLogin() {
		btn.click();
		return new HomePage(driver);
	}
	
	public void enterUsername(String n) {
		name.clear();
		name.sendKeys(n);
	}
	public void enterPassword(String p) {
		pass.clear();
		pass.sendKeys(p);
	}
	public HomePage closePage() {
		close.click();
		return new HomePage(driver);
	}
	public String nullValidation() {
		String nullalert=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		return nullalert;
		
	}
	public String invalidValidation() {
		String invalidalert=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		return invalidalert;
		
	}
	
	

}
