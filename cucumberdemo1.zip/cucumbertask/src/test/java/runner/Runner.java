package runner;

import glue.W;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;
/*
The @RunWith(Cucumber.class) annotation tells JUnit to run the tests using the Cucumber runner.

The @CucumberOptions annotation is used to configure the Cucumber runner.
Here are the options:

dryRun: This option is set to false, which means that the tests will actually be run.
If it were set to true, the tests would be run in "dry run" mode,
which means that the tests would be run without actually executing the steps,
but instead, they would be printed out.
monochrome: This option is set to false, which means that the output of the tests
will be colorized. If it were set to true, the output of the tests would not be colorized.
 */
@RunWith(Cucumber.class)

@CucumberOptions(
        dryRun = false,
        monochrome = false,
        features = {"src/test/resources/tests"},
        glue = {"glue"},
        plugin = {"html:target/cucumber-html/cucumber.html", "json:target/cucumber-json/cucumber.json"},
        tags = ""
)
public class Runner {
    @AfterClass
    public static void close() {
        W.close();
    }
}
