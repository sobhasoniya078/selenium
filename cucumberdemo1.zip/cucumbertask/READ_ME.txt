Topics:
Maven, Java, BDD, Cucumber, Gherkin, Selenium, Git, Junit.

Notes:
Use cucumber filter tags to execute the full regression or the test currently in development.

You can either run the maven goal test or use a Junit runner within the IDE - use the VM variable cucumber.filter.tags
For example;
mvn test -Dcucumber.filter.tags="@develop"
mvn test -Dcucumber.filter.tags="@regression"



(Selenium, Cucumber, Java, Junit, Maven)
Google - Implement the pre-written scenarios using Selenium Webdriver. The Driver is configured to use chrome.
You will need to pass in the path to a chrome driver.

(BDD, Gherkin)
Password Change - Complete the feature file to describe the scenarios required to test a standard 'password change'
functionality. It can be assumed there are a few rules that the new password must comply with. You must specify the
current username and password before being allowed to enter a new password and confirm the new password by re-typing
the same. You DO NOT need to implement any steps.