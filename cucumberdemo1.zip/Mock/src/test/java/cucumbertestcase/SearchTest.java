package cucumbertestcase;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import base.Reusable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePage;
import pom.LoginPage;
import pom.SearchResultPage;
import utils.ExtentReport;

@Listeners(ExtentReport.class)
public class SearchTest extends Reusable{
	public static WebDriver driver;
	LoginPage lp;
	HomePage hp;
	SearchResultPage srp;
    @Before
    public void openBrowser(){
    	driver=Reusable.invokeBrowser();
		
		lp=new LoginPage(driver);
		hp= new HomePage(driver);
		srp= new SearchResultPage(driver);
    }
    @After
    public void closeBrowser(){
       
        driver.quit();
    }
    @Given("user is in the homepage")
    public void user_is_in_the_homepage() {
    	driver.get(pro.getProperty("url"));
    }
    @Given("clicking the search bar")
    public void clicking_the_search_bar() {
    	hp.clicksearch();
        }
    @When("sending the invalid string")
    public void sending_the_invalid_string() {
        hp.enterInValid(); }
    @Then("validate the errormsg")
    public void validate_the_errormsg() {
       Boolean res=srp.notFound(); 
       assertEquals(res,true);
       }
    @When("sending the valid string")
    public void sending_the_valid_string() {
       hp.enterValid(); }
    @Then("validate the resultpage")
    public void validate_the_resultpage() {
        Boolean resl=srp.found();
        assertEquals(resl,true);
        }
    @When("sending the null value")
    public void sending_the_null_value() {
    	hp.nullValue();
        }
    @Then("verify the null search")
    public void verify_the_null_search() {
    	 Boolean res=srp.notFound(); 
         assertEquals(res,true);
         }
    

}
