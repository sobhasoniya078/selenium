package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchResultPage {

	WebDriver driver;
	@FindBy(className="noProducts")
	WebElement res;
	@FindBy(className="select")
	WebElement msg;
	public SearchResultPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public Boolean notFound() {
		return res.isDisplayed();
		
	}
	public Boolean found() {
		return msg.isDisplayed();
		
	}
}
