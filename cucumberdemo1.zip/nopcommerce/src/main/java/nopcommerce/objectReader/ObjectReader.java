package nopcommerce.objectReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader {
	//create obj for properties class
	Properties pro;
	public ObjectReader() throws IOException {
		String path=System.getProperty("user.dir")+"\\objectrepository\\objectRepo";
		FileReader reader=new FileReader(path);
		pro=new Properties();
		pro.load(reader);
	}
	public String getBaseUrl() {
		return pro.getProperty("baseUrl");
		
		
	}

}
