package nopcommerce.testcases;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import nopcommerce.driverimplementation.DriverClass;
import nopcommerce.objectReader.ObjectReader;
import nopcommerce.pages.Login;
import nopcommerce.pages.Search;
import nopcommerce.utils.Reusable;

import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class VerifyLogin {
	WebDriver driver;
	DriverClass dr;
	ObjectReader or;
	Login l;
	Search s;
	ExtentReports report;
	ExtentSparkReporter spark;
	Reusable r;

	@Test(priority = 1)//verify the login if the login got failed then register
	public void verifyUserReg() throws IOException {
		ExtentTest test = null;
		try {
			test = report.createTest("verifying the login function");
			driver = l.login();
			String s = l.title();
			assertEquals(s, "nopCommerce demo store. Login");

			test.log(Status.PASS, "Form submitted successfully");
			test.assignAuthor("sobha").assignDevice("windows");
		} catch (Exception e) // if the testcase got failed ..took the screenshot and log as failed
		{
			//driver=l.uesrReg();
			test.log(Status.FAIL, "form not submitted: " + e.getMessage());
			test.assignAuthor("sobha").assignDevice("Windows").assignDevice("Chrome");

			// took a sc
			Reusable.takeScreenshot(driver);
		}

	}

	@Test(priority = 2)//verify the search product
	public void verifySearch() {
		driver = s.searchProduct();
		String key=s.keyword();
		assertEquals(s,"Cell phones");

	}

	@Test(priority = 3) //verify the add to cart
	public void verifyAddTocart() throws IOException {
		ExtentTest test1 = null;
		try {
			driver = s.addToCart();
			boolean al = s.getalert();
			assertEquals(al, "true");
			test1.log(Status.PASS, "product added to the cart");
			test1.assignAuthor("sobha").assignDevice("windows");
		} catch (Exception e) // if the testcase got failed ..took the screenshot and log as failed
		{
			test1.log(Status.FAIL, "cannot added to cart: " + e.getMessage());
			test1.assignAuthor("sobha").assignDevice("Windows").assignDevice("Chrome");

			// took a sc
			Reusable.takeScreenshot(driver);
		}
	}

	

	@BeforeClass
	public void beforeClass() throws IOException {
		// call the driver method from the class
		dr = new DriverClass();
		driver = dr.chrome();
		// pass the base url
		or = new ObjectReader();
		driver.get(or.getBaseUrl());
		// registration
		l = new Login(driver);
		// Search
		s = new Search(driver);
		// extentReport
		report = new ExtentReports();
		spark = new ExtentSparkReporter("reports/login.html");
		report.attachReporter(spark);
		// screenshot
		r = new Reusable();

	}

	@AfterClass
	public void afterClass() {
		driver.quit();
		report.flush();
	}

}
