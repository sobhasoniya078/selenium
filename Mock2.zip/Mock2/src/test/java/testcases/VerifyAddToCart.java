package testcases;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Reusable;
import pom.CartPage;
import pom.HomePage;
import pom.ProductPage;
import utils.ExtentReport;

@Listeners(ExtentReport.class)
public class VerifyAddToCart extends Reusable{
	WebDriver driver;
	ProductPage pp;
	HomePage hp;
	CartPage cp;
	
	@BeforeTest
	public void setup() {
		driver=Reusable.invokeBrowser();
		driver.get(pro.getProperty("url"));
		pp= new ProductPage(driver);
		hp= new HomePage(driver);
		cp= new CartPage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@AfterTest
	 public void afterTest() {
		 driver.quit();
	 }
	@Test(priority=1)
	public void verifyCart() throws InterruptedException {
		hp.clickCategory();
		hp.chooseProduct();
		pp.addToCart();
		Thread.sleep(4000);
		String exp="Product added";
		String res=pp.verifycart();
		assertEquals(exp,res);
		
	}
	@Test(priority=2)
	 public void verifyRemoveFromcart() throws InterruptedException {
		 pp.Viewcart();
		 cp.removeProduct();
		 Thread.sleep(4000);
		 Boolean del=cp.verifyDelete();
		 assertEquals(del,false);
	 }

}
