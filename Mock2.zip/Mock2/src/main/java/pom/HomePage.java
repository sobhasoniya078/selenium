package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
WebDriver driver;
@FindBy(linkText="Phones")
WebElement phn;
	
	@FindBy(id="login2")
	WebElement log;
	
	@FindBy(id="logout2")
	WebElement logout;
	@FindBy(className="card-img-top")
	WebElement product;
	
	@FindBy(id="signin2")
	WebElement sign;		
	/************************constructor***************************/
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public LoginPage enterIntoLoginpage() {
		log.click();
		return new LoginPage(driver);
	}
	public Boolean validateLogout() {
		 return logout.isDisplayed();
	}
	public void clickCategory()
	{
		phn.click();
	}
	public ProductPage chooseProduct() {
		product.click();
		return new ProductPage(driver);
	}
	public SignInPage enterIntoSignupPage() {
		sign.click();
		return new SignInPage(driver);
	}
	

}
