package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPage {
	
	WebDriver driver;
	@FindBy(linkText="Add to cart")
	WebElement cart;
	
	@FindBy(linkText="Cart")
	WebElement viewcart;
	
	public ProductPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public void addToCart() {
		cart.click();
		
	}
	
	public String verifycart() {
		String alert=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		return alert;
	}
	public CartPage Viewcart() {
		viewcart .click();
		return new CartPage(driver);
	}
	

	
	
	

}
