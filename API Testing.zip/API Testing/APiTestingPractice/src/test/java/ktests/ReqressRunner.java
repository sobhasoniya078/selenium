package ktests;

import com.intuit.karate.junit5.Karate;

public class ReqressRunner {
	
	@Karate.Test
	 public Karate runTest() {
		 
		return Karate.run("regress.feature").relativeTo(getClass());
		 
	 }

}
