package ktest;

import com.intuit.karate.junit5.Karate;

public class Runner {

	@Karate.Test
	public Karate test() {
		return Karate.run("reqress.feature").relativeTo(getClass());}
}
