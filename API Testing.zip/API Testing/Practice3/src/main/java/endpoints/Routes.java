package endpoints;

public class Routes {
	public static String baseuri="http://universities.hipolabs.com/";
	public static String search="search?name=middle";
  
	public static String Baseurii="http://universities.hipolabs.com/search?name=middle";
}
