package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UserEndpoints {
	
	public static Response search() {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseuri).basePath(Routes.search).contentType("application/json")
				.accept("application/json").when().get();
		return res;
		
	}
	public static Response searchSchema() {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.Baseurii).contentType("application/json")
				.accept("application/json").when().get();
		return res;
		
	}
	

}
