package Testcase;
import static org.hamcrest.CoreMatchers.equalTo;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.junit.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;

@Listeners(utilities.ExtentReportsListener.class)
public class search {
	
	@BeforeTest
	public void before() {
		RestAssured.useRelaxedHTTPSValidation();
	}
	@Test
	public void searchRes() {
		Response res=UserEndpoints.search();
		 res.then().log().all()
		
		 .contentType("application/json")
			.body("[0].alpha_two_code", equalTo("GB"));
		 res.then()
			.assertThat()
		.body(matchesJsonSchema(new File(System.getProperty("user.dir")+"\\src\\test\\resource\\payloads\\search.json")));
		
		 assertEquals(res.getStatusCode(), 200);
		
	}
	

}
