package endpoints;

public class Routes {
	public static String baseUri="https://reqres.in";
	public static String get="/api/unknown";
	public static String put="/api/users/{id}";
	public static String Post="/api/users";
	public static String Delete="/api/users/{id}";

}
