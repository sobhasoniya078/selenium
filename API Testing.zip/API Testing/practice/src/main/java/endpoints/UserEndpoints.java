package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.UserModel;

public class UserEndpoints {
	
	public static Response getData() {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.get).contentType("application/json").accept("application/json")
				.when().get();
		return res;
	}
	
	public static Response postData(UserModel payload) {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.Post).contentType("application/json").accept("application/json")
				.body(payload)
				.when().post();
		return res;
	}
	
	public static Response putData(long id,UserModel payload) {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.put).pathParam("id",id)
				.contentType("application/json").accept("application/json")
				.body(payload)
				.when().post();
		return res;
	}
	public static Response delete(int i) {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.Delete).pathParam("id",i)
				.contentType("application/json").accept("application/json")
				
				.when().delete();
		return res;
	}
	

}
