package test;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.UserModel;

public class Crud {
	
	UserModel us;
	
	@BeforeTest
	public void setup() {
		us= new UserModel(1,"sobha@gmail","sobha","soniya","avt");
		RestAssured.useRelaxedHTTPSValidation();
	}
	@Test
	public void read() {
		Response res=UserEndpoints.getData();
				res.then().log().all();
				assertEquals(res.getStatusCode(), 200);
	}
	
	@Test
	public void create() {
		Response res=UserEndpoints.postData(us);
				res.then().log().all();
				assertEquals(res.getStatusCode(), 201);
	}
	
	@Test
	public void update() {
		Response res=UserEndpoints.putData(1, us);
				res.then().log().all();
				assertEquals(res.getStatusCode(), 201);
	}
	
	@Test
	public void delete() {
		Response res=UserEndpoints.delete(1);
				res.then().log().all();
				assertEquals(res.getStatusCode(), 204);
	}
	
	
	

}
