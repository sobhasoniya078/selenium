package tests;


import static io.restassured.RestAssured.given;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;



public class Testcase {
	// gets executed only once
		@BeforeTest
		public static void beforeTestExecution() {
			
			RestAssured.baseURI = "https://reqres.in";
			RestAssured.useRelaxedHTTPSValidation();
		}
		
		@Test
		public void getAllUsers() {
			

			given().when().get("/api/users/2")
			.then().assertThat().statusCode(200)
	        .contentType("application/json");
		}
		

}
