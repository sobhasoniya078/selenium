package endpoints;

import io.restassured.RestAssured;

public class UserEndpoints {
	public Response listAllBooks() {
		Response res=RestAssured.given()
				.headers("Content-Type",Content)
	}

}
