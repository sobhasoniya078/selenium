package endpoints;

public class Routes {
	
	public static String  baseUri="https://fakerestapi.azurewebsites.net/api/v1/";
	public static String get="Books";

}
