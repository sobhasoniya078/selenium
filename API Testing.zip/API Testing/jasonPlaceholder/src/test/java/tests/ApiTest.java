package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.hamcrest.Matcher;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.UserModel;

@Listeners(utilities.ExtentReportsListener.class)
public class ApiTest {
	public UserModel um;

	@BeforeClass
	public  void setup() {
		RestAssured.useRelaxedHTTPSValidation();
		um= new UserModel(1,"sobha","soniya",1);
		
	}
	@Test
	public void getAllResources() {
		Response res=UserEndpoints.getAllResource();
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
	@Test
	public void getSingle() {
		Response response = UserEndpoints.getaSingleResource(um.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	@Test
	public void CreateResource() {
		UserModel payload5 = new UserModel(1, "foo", "Hellooo", 1);
		Response response = UserEndpoints.CreateUser( payload5);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 201);
	}
	
	@Test
	public void updateResourcePut() {
		UserModel payload2 = new UserModel(1, "foo", "bar", 1);
		Response response = UserEndpoints.updateResource(um.getId(), payload2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	@Test
	public void patchReqTest() {
		UserModel payload3 = new UserModel(1, "foo", "Hellooo", 1);
		Response response = UserEndpoints.patchResource(um.getId(), payload3);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	@Test
	public void deleteReqTest() {
		Response response = UserEndpoints.deleteresource(um.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	/*
	 * @Test public void schemavalidation() { Response response =
	 * UserEndpoints.schemaValid();
	 * response.then().assertThat().body(matchesJsonSchema(new
	 * File(System.getProperty("user.dir")+
	 * "\\src\\test\\resource\\payloads\\schema.json"))); }
	 */
	
	
	
	
}
