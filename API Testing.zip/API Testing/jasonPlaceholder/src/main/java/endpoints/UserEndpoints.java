package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.UserModel;

public class UserEndpoints {
	 public static Response getAllResource() {
		 Response res=RestAssured.given()
				 .headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				 .baseUri(Routes.baseUri)
				 .basePath(Routes.get_all)
				 .contentType("application/json")
				.accept(ContentType.JSON)
				 .when().get();
		return res;
		 
	 }
	 
	 public static Response CreateUser(UserModel payload) {
		 Response res=RestAssured.given()
				 .headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				 .baseUri(Routes.baseUri)
				 .basePath(Routes.create)
				 .contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return res;
		 
	 }
	 public static Response getaSingleResource(int id) {
			Response response= RestAssured.given()
					.headers(
							
							"Content-Type",
							ContentType.JSON,
							"Accept",
							ContentType.JSON)
					.baseUri(Routes.baseUri)
					.basePath(Routes.get_single)
					.pathParam("id", id)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.get();
			return response;
		}
	 

	 public static Response updateResource(int id, UserModel payload) {
			Response response= RestAssured.given()
					.headers(
							"Content-Type",
							ContentType.JSON,
							"Accept",ContentType.JSON)
					.baseUri(Routes.baseUri)
					.basePath(Routes.update)
					.pathParam("id", id)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.body(payload)
					.when()
					.put();
			return response;
		}
	 public static Response patchResource(int id, UserModel payload) {
			Response response= RestAssured.given()
					.headers(
							"Content-Type",
							ContentType.JSON,
							"Accept",
							ContentType.JSON)
					.baseUri(Routes.baseUri)
					.basePath(Routes.patch)
					.pathParam("id", id)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.body(payload)
					.when()
					.patch();
			return response;		
		}
	 public static Response deleteresource(int id) {
			Response response= RestAssured.given()
					.headers(
							"Content-Type",
							ContentType.JSON,
							"Accept",
							ContentType.JSON)
					.baseUri(Routes.baseUri)
					.basePath(Routes.delete)
					.pathParam("id", id)
					.contentType("application/json")
					.accept(ContentType.JSON)
					.when()
					.delete();
			return response;
		}
	 public static Response schemaValid() {
			Response response=RestAssured.given()
		    .baseUri(Routes.baseUrii)
		    .when()
		    .get();
			return response;
		}
	 
}
