package payloads;

public class UserModel {
	 public int id;
	 public String title;
	 public String body;
	 public int UserId;
	 
	 @Override
	public String toString() {
		return "UserModel [id=" + id + ", title=" + title + ", body=" + body + ", UserId=" + UserId + ", getId()="
				+ getId() + ", getTitle()=" + getTitle() + ", getBody()=" + getBody() + ", getUserId()=" + getUserId()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	 

	public UserModel(int id, String title, String body, int userId) {
		
		this.id = id;
		this.title = title;
		this.body = body;
		this.UserId = userId;
	}
	
public UserModel() {}

	public UserModel(String title, String body, int userId) {
		super();
		this.title = title;
		this.body = body;
		UserId = userId;
	}


	public int getId() {
		return id;
	}
	 
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	

}
