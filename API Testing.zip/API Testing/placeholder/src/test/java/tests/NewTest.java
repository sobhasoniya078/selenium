package tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import endpoints.UserEndpoint;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;

public class NewTest {
	Usermodel um;
	@BeforeClass
	public void setup() {
		RestAssured.useRelaxedHTTPSValidation();
		um=new Usermodel(7,2019,1849.99,"Apple MacBook Pro 16","Intel Core i9");
	}
	@Test(priority=0)
	public void getAll() {
		Response response =UserEndpoint.getAllResources();
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=1)
	public void creteUser() {
		Response response =UserEndpoint.createResource(um);
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=2)
	public void updateUser() {
		Response response =UserEndpoint.createResource(um);
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=3)
	public void deleteUser() {
		Response response =UserEndpoint.delete(um.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
	}
	

}
