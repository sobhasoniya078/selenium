package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;

@Listeners(utilities.ExtentReportsListener.class)
public class ApiTest {
	public Usermodel us;
	
	@BeforeTest
	public  void setup() {
		RestAssured.useRelaxedHTTPSValidation();
		us=new Usermodel(1,"foo","bar",1);
		
	}
	
	@Test(priority=0)
	public void getAll() {
		Response response =UserEndpoints.getAllResources();
		response.then().log().all();
		assertEquals(response.getStatusCode(),200);
		
	}
	
	@Test(priority=1)
	public void createResource() {
	Usermodel us1=new Usermodel(1,"foooooo","sobhasoniya",1);
	Response res=UserEndpoints.createResource(us1);
	res.then().log().all();
	assertEquals(res.getStatusCode(),201);
		
	}
	
	@Test(priority=2)
	public void getSingleUser() {
		Usermodel us2=new Usermodel();
		Response res=UserEndpoints.singleResource(1);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
		
	}
	
	@Test(priority=3)
	public void updateResource() {
		Usermodel us3=new Usermodel(1,"sobha","soniya",1);
		Response res=UserEndpoints.update(1,us3);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
		
	}
	
	@Test(priority=4)
	public void deleteResource() {
		Usermodel us4=new Usermodel();
		Response res=UserEndpoints.delete(1);
		res.then().log().all();
		assertEquals(res.getStatusCode(),200);
	}
	@Test(priority=5)
	public void schemaValidation() {
		RestAssured.given().baseUri(Routes.baseUrii)
		.when().get().then().assertThat()
		.body(matchesJsonSchema(new File("C:\\Users\\271501\\Documents\\API Testing\\placeholder\\src\\test\\resource\\schema.json")));
	}

}
