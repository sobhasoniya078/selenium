package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.Usermodel;

public class UserEndpoint {

	public static Response getAllResources() {
		Response response= RestAssured.given()
				.headers("Content-Type",
				ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Route.baseuri)
				.basePath(Route.get)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;
	}
	public static Response createResource(Usermodel payload) {
		Response response=RestAssured.given()
				.headers(
						"Content-Type",
						ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Route.baseuri)
				.basePath(Route.post)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;
	}
	public static Response update(int id,Usermodel payload) {
		Response res=RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Route.baseuri)
				.basePath(Route.put)
				.pathParams("id",id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when().put();
		return res; 

}
	public static Response delete(int id) {
		Response res =RestAssured.given()
				.headers("Content-Type",ContentType.JSON,"Accept",ContentType.JSON)
				.baseUri(Route.baseuri)
				.basePath(Routes.delete)
				.pathParams("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when().delete();
		return res;
	}
	}
