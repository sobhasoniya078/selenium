package endpoints;

public class Routes {
	public static String baseUri="https://jsonplaceholder.typicode.com/";
	public static String get_all="posts";
	public static String get_single="posts/{id}";
	public static String create="posts";
	public static String update="posts/{id}";
	public static String patch="posts/{id}";
	public static String delete="posts/{id}";
	public static String baseUrii="https://jsonplaceholder.typicode.com/posts/{id}";

}
