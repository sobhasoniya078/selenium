package endpoints;

public class Route {

	public static String baseuri="https://api.restful-api.dev";
	public static String get="/objects";
	public static String put="objects/{id}";
	public static String post="objects";
	public static String delete="objects/{id}";
	public static String get1="objects/{id}";
}
