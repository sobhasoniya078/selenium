package payloads;

public class Usermodel {
	public int id;
	public int year;
	public double price;
	public String name;
	public String CPU_price;
	
	public int getId() {
		return year;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public Usermodel() {}
	public Usermodel(int id,int year, double price, String name, String cPU_price) {
		
		this.year = year;
		this.price = price;
		this.name = name;
		this.CPU_price = cPU_price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCPU_price() {
		return CPU_price;
	}
	public void setCPU_price(String cPU_price) {
		CPU_price = cPU_price;
	}
	public int getHarddisksize() {
		return Harddisksize;
	}
	public void setHarddisksize(int harddisksize) {
		Harddisksize = harddisksize;
	}
	public int Harddisksize;

}
