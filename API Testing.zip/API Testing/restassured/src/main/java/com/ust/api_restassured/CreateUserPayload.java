package com.ust.api_restassured;


public class CreateUserPayload
{
	public String payloadString()
	{
		return "{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}";
	}
	
	
	public static String payloadparams(String name, String job) {
        return "{\r\n"
                + "    \"name\": \"" + name + "\",\r\n"
                + "    \"job\": \"" + job + "\"\r\n"
                + "}\r\n";
    }
}