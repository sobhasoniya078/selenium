package com.ust.api_restassured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import io.restassured.RestAssured;


public class RestAssuredAPI {
	static CreateUserPayload payload;
	static String path="C:\\Users\\271509\\eclipse-workspace2\\RestAssured\\json\\create.json";
	
	
	
	
	public static void main(String[] args) {
		
		RestAssuredAPI retobj= new RestAssuredAPI();
		//retobj.create();
		create("morpheus","leader");
		//create();
		//getsingle();
	}
	public static void getAllUsers() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = "https://reqres.in";
		given()
		.log().all()
		.queryParam("page", 2)
		.when().get("/api/users")
		.then().log().all().assertThat().statusCode(200)
		.body("page",equalTo(2));
		
	}
	public static void getsingle(int id) {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = "https://reqres.in";
		given().log().all()
		.when().get("/api/users/"+id+"")
		.then().log().all().assertThat().statusCode(200)
		.body("data.id",equalTo(2));
	}
	public static void create(String name,String job) {
		payload=new CreateUserPayload();
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = "https://reqres.in";
		given().log().all()
		.header("Content-Type","application/json; charset=utf-8")
		.body(CreateUserPayload.payloadparams(name, job))
		.when().post("/api/users")
		.then().log().all().assertThat().statusCode(201)
		.body("name",equalTo(name));
		
		
		
		
//		given().log().all()
//		.header("Content-Type","application/json; charset=utf-8")
//		.body(createUserPayload.payloadparams(name, job))
//		.when().post("/api/users")
//		.then().log().all().assertThat().statusCode(201)
//		.body("name", equalTo(name));
	}
}