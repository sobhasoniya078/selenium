package com.ust.api_restassured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import io.restassured.RestAssured;

public class ReqresAPI {
	public void getAllUsers() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = "https://reqres.in";
		given().log().all().queryParam("page", 2).when().get("/api/users").then().log().all().assertThat()
				.statusCode(200).body("total", equalTo(12));
	}

	public static void main(String[] args) {

		ReqresAPI obj = new ReqresAPI();
		obj.getAllUsers();
	}

}
