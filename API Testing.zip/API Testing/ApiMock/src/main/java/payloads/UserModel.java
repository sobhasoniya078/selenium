package payloads;

public class UserModel {
	
    public String name;
	public int salary;
	public int age;
	public int id;
	public UserModel(String name, int salary, int age, int id) {
		super();
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.id = id;
	}
	public UserModel(int id) {
		super();
		this.id = id;
	}

	public UserModel() {}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "UserModel [name=" + name + ", salary=" + salary + ", age=" + age + ", id=" + id + ", getName()="
				+ getName() + ", getSalary()=" + getSalary() + ", getAge()=" + getAge() + ", getId()=" + getId()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
}
