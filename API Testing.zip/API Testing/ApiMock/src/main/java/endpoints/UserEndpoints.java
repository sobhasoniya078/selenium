package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.UserModel;



public class UserEndpoints {

	public static Response listAllUsers() {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.get)
				
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	public static Response getSingleUser(int id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.getsingle)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	public static Response createUser(UserModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.create)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}
public static Response updateUser(int id, UserModel payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseuri)
				.basePath(Routes.update)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
public static Response deleteUser(int id) {
	Response response = RestAssured.given()
			.headers(
					
					"Content-Type",
					ContentType.JSON,
					"Accept",
					ContentType.JSON)
			.baseUri(Routes.baseuri)
			.basePath(Routes.delete)
			.pathParam("id", id)
			.contentType("application/json")
			.accept(ContentType.JSON)
			.when()
			.delete();
	return response;	
}

}
