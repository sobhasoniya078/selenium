package endpoints;

public class Routes {
	public static String baseuri="https://dummy.restapiexample.com/api/";
	public static String get="v1/employees";
	public static String getsingle="v1/employee/{id}";
	public static String create="v1/create";
	public static String update="v1/update/21";
	public static String delete="v1/delete/2";

}
