package Tests;

import static org.testng.Assert.assertEquals;


import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.UserModel;




@Listeners(utilities.ExtentReportListener.class)
public class ApiTest {
	public UserModel um;
	
	@BeforeClass
		public void setup() {
			um=new UserModel("sobhaa",123,23,1);
			RestAssured.useRelaxedHTTPSValidation();
		}
	@Test
	public void getUsers() {
		Response res=UserEndpoints.listAllUsers();
		res.then().log().all();
		assertEquals(res.statusCode(),200);
	}
	
	@Test
	public void getSingleUser(int id) {
		Response res=UserEndpoints.getSingleUser(1);
		res.then().log().all();
		assertEquals(res.statusCode(),200);
	}
	@Test 
	public void createUser(String name,int salary,int age) {
		Response res=UserEndpoints.createUser(um);
		res.then().log().all();
		assertEquals(res.statusCode(),200);
		
	}
	
	@Test
	public void updateUser(String name,int salary,int age) {
		Response res=UserEndpoints.updateUser(1, um);
		res.then().and().log().all();
		assertEquals(res.statusCode(),200);
	}
	@Test
	public void deleteUser(int id) {
		Response res=UserEndpoints.deleteUser(1);
		res.then().log().all();
		assertEquals(res.statusCode(),200);
			
	}
	}
	


