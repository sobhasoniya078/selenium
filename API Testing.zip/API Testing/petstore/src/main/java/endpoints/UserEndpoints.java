package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.UserModels;

public class UserEndpoints {

	// method for get all endpoint
	public static Response getListUser() {
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.get_all).contentType("application/json")
				.accept(ContentType.JSON).when().get();
		return response;
	}

	// method for processing get single endpoint
	public static Response getUser(int id) {
		Response response = RestAssured.given().headers(

				"Content-Type", ContentType.JSON, "Accept", ContentType.JSON).baseUri(Routes.baseUri)
				.basePath(Routes.getSingle).pathParam("id", id).contentType("application/json").accept(ContentType.JSON)
				.when().get();
		return response;
	}

	// method for post_createing a order
	public static Response createOrder(UserModels um) {
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.post).contentType("application/json").accept(ContentType.JSON)
				.body(um).when().post();
		return response;
	}

	// method for delete operation
	public static Response deleteOrder(int id) {
		Response response = RestAssured.given().headers("Content-Type", ContentType.JSON, "Accept", ContentType.JSON)
				.baseUri(Routes.baseUri).basePath(Routes.delete).pathParam("id", id).contentType("application/json")
				.accept(ContentType.JSON).when().delete();
		return response;
	}

	// there is no put or patch request in the given api

}
