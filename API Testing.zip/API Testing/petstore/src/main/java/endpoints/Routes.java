package endpoints;

public class Routes {
	public static String baseUri = "https://petstore.swagger.io/v2/";
	public static String get_all = "store/inventory";
	public static String post = "store/order";
	public static String getSingle = "store/order/{id}";
	public static String delete = "store/order/{id}";

}
