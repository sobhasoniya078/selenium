package cucumbertestcase;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Reusable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePage;
import pom.SearchResultPage;

public class SearchTest extends Reusable{
	WebDriver driver;
	HomePage hp;
	SearchResultPage srp;
	@Before
	public void setup() {
		driver=Reusable.invokeBrowser();
		srp=new SearchResultPage(driver);
		hp=new HomePage(driver);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@After
	public void teardown() throws InterruptedException {
		//Thread.sleep(3000);
		driver.close();
	}
	@Given("the user in the search page")
	public void the_user_in_the_search_page() {
		driver.get(pro.getProperty("url"));
	    
	}
	@When("user click the search bar")
	public void user_click_the_search_bar() {
		hp.clicksearch();
	}
	@When("the search button is clicked")
	public void the_search_button_is_clicked() {
	    hp.notifyAll();
	}
	@Then("the error msg should be displayed")
	public void the_error_msg_should_be_displayed() {
	   Boolean res= srp.notFound();
	   assertEquals(res,true);
	}
	@When("user pass the invalid value")
	public void user_pass_the_invalid_value() {
	    
	    hp.enterInValid();
	}
	
	@Then("the error message should be displayed")
	public void the_error_message_should_be_displayed() {
		Boolean res= srp.notFound();
		   assertEquals(res,true);
	}
	@When("user pass the valid value")
	public void user_pass_the_valid_value() {
		 hp.enterValid();
	}
	
	@Then("the results will be displayed")
	public void the_results_will_be_displayed() {
	    
	}

}
