package testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Reusable;
import pom.HomePage;
import pom.LoginPage;

import utils.ExcelReader;
import utils.ExtentReport;


@Listeners(ExtentReport.class)
public class VerifyLogin extends Reusable {
	
	
	WebDriver driver;
	LoginPage lp;
	HomePage hp;
	@BeforeTest
	public void setup() {
		driver=Reusable.invokeBrowser();
		driver.get(pro.getProperty("url"));
		lp=new LoginPage(driver);
		hp= new HomePage(driver);
	}
	@Test(dataProvider = "valid") 
	  public void verifyvalidLogin(String n, String s) throws InterruptedException {
		  System.out.println(n+s);
		  
		  lp.enterUserName(n);
		  lp.enterPassword(s);
	      lp.clikSignIn();
	      Boolean res=hp.iconVerify();
	      assertEquals(res,true);
	
	  }
	@Test(dataProvider = "invalid") 
	  public void verifyInvalidLogin(String n, String s) throws InterruptedException {
		  System.out.println(n+s);
		  Thread.sleep(2000);
		  hp.clickIcon();
		  Thread.sleep(2000);
		  lp.enterUserName(n);
		  lp.enterPassword(s);
	      lp.clikSignIn();
	      Boolean res=lp.ErrorMsg();
	      assertEquals(res,true);
	      
	
	  }
	@Test
	public void nullLogin() {
		lp.clikSignIn();
		Boolean res=lp.nullErr();
		assertEquals(res,true);
	}
	
	@AfterTest
	 public void afterTest() {
		 driver.quit();
	 }
	  
	  @DataProvider public String[][] valid() throws IOException { 
		  String path=System.getProperty("user.dir")+"\\src\\test\\resources\\datasource\\data.xlsx"; 
		  return ExcelReader.locate(path,"validData");
	  
	  }
	  @DataProvider public String[][] invalid() throws IOException { 
		  String path=System.getProperty("user.dir")+"\\src\\test\\resources\\datasource\\data.xlsx"; 
		  return ExcelReader.locate(path,"invalidData");
	  
	  }


}
