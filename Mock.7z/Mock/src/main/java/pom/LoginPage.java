package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	WebDriver driver;
	
	@FindBy(name="username")
	WebElement name;
	@FindBy(name="password")
	WebElement pass;
	@FindBy(id="sign_in_btn")
	WebElement sign;
	@FindBy(id="signInResultMessage")
	WebElement msg;
	@FindBy(className="invalid")
	WebElement err;
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	 
	public void enterUserName(String n) {
		name.clear();
		name.sendKeys(n);
	}
    public void enterPassword(String p) {
    	name.clear();
    	pass.sendKeys(p);
		
	}
    public HomePage clikSignIn() {
    	sign.click();
    	return new HomePage(driver);
    	
    }
    public Boolean ErrorMsg() {
    	return msg.isDisplayed();
    }
    public Boolean nullErr() {
    	return err.isDisplayed();
    }

}
