package pom;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;
	@FindBy(id="hrefUserIcon")
	WebElement icon;
	@FindBy(id="menuSearch")
	WebElement search;
	
	@FindBy(id="autoComplete")
	WebElement val;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public LoginPage clickIcon() {
		icon.click();
		return new LoginPage(driver);
	}

	public Boolean iconVerify() {
		return icon.isDisplayed();
		
	}
	public void clicksearch() {
		search.click();
	}
	public SearchResultPage enterValid() {
		val.sendKeys("shirt"+Keys.ENTER);
		return new SearchResultPage(driver);
	}
	public SearchResultPage enterInValid() {
		val.sendKeys("laptop"+Keys.ENTER);
		return new SearchResultPage(driver);
	}
	public SearchResultPage nullValue() {
		val.sendKeys(Keys.ENTER);
		return new SearchResultPage(driver);
	}
}
